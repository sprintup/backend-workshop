'use strict';

var angular = require('angular');

angular.module('todoListApp', []);
require('./scripts/services');
require('./scripts/directives');
require('./scripts/controllers');
