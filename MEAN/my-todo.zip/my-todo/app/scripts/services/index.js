'use strict';

var angular = require('angular');

angular.module('todoListApp')
.service('dataService'), require('./data');