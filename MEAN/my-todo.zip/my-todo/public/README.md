# angular-basics
The Angular Basics course is taught in workspaces.  This is the code for the final course app.

# set-up
```
git clone <this-repo>
cd <this-repo>
http-server -p 3000
# visit localhost:3000 to see the todoListApp
